<footer id="pied_de_page">
    <p>Copyright Gérard Tio Nogueras, tous droits réservés</p>
</footer>