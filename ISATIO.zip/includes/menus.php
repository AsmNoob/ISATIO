<!--<p style="font-size:50px; text-align: center;">Isatio</p>-->
<div style="text-align: center;">
	<nav>
	<a href="../index.php">Home</a>
	<a href="../gallery.php">Gallery</a>
	<a href="../events.php">Events</a>
	<a href="../contact.php">Contact</a>
	</nav>
</div>