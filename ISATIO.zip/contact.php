<!DOCTYPE html>
<html lang='en'>
<?php include("./includes/header.php"); ?>

<body class="general">
<?php include("./includes/logo.php");?>
<?php include("./includes/menus.php"); ?>
	<!--<img style="width: 750%;margin-top: 40px" src="img/Logo.jpg">-->
	<div><h3>Pour consulter ma page facebook :</h3>
	<a style="text-align:right;" href="https://www.facebook.com/pages/Isatio-In-the-mood-for-recycling/1436212216611631?fref=ts"><img src="img/logoFacebook.png"></a></div>
	<div><h1>Contact</h1>
	<p>Utilisez mon mail <b>fashion@isatiodesign.com</b> pour me contacter.</p>
	<p>Pour vous inscrire à ma mailinglist et être prévenu de mes ventes, envoyez moi votre adresse par mail.</p></div>
	<!--Ecrire un formulaire ici, à sauver ds la db-->
</body>
</html>