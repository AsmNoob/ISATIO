<!DOCTYPE html>
<html lang='en'>
<?php include("./includes/header.php"); ?>

<body class="general">
<?php include("./includes/logo.php");?>
<?php include("./includes/menus.php"); ?>
</body>
</html>