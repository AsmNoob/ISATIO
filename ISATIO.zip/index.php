<!DOCTYPE html>
<html lang='en'>

<?php include("./includes/header.php"); ?>

<body class="general">

<?php include("./includes/logo.php");?>
<?php include("./includes/menus.php"); ?>

<!--Idee-->








<h1>En Construction...</h1>

    <!--<div>
        <div>
            <a href="#"><img style="width:330px" src="img/2duh1lk.jpg"></a>
        </div>
        <div>
            <a href="#"><img style="width:330px" src="img/k9j4ub.jpg"></a>
        </div>
    </div>
    <div>
        <div>
            <a href="#"><img style="width:330px" src="img/zlt5s6.jpg"></a>
        </div>
        <div>
            <a href="#"><img style="width:330px" src="img/qz1yzp.jpg"></a>
        </div>
    </div>-->

    </div>
    <!--<form action="cible_envoi.php" method="post" enctype="multipart/form-data">
            Formulaire d'envoi de fichier :<br />  
            <input type="file" name="monfichier" />
            <input type="submit" value="Envoyer le fichier" />
    </form>-->

</body>
</html> 